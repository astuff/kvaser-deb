var searchData=
[
  ['sending_20and_20receiving',['Sending and Receiving',['../page_user_guide_send_recv.html',1,'page_user_guide']]]
];
