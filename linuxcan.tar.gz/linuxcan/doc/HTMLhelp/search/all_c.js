var searchData=
[
  ['nodes',['Nodes',['../group__kvadb__nodes.html',1,'']]],
  ['name',['name',['../structtag__token.html#a5ac083a645d964373f022d03df4849c8',1,'tag_token']]],
  ['named_20parameter_20settings',['Named Parameter Settings',['../group___named_parameter_settings.html',1,'']]],
  ['next',['next',['../structtag__token.html#abbda7319715f980cc994d557e68e11e7',1,'tag_token::next()'],['../struct_kv_parse_handle.html#a68f64b5ffe49f617e182b80d771ae645',1,'KvParseHandle::next()']]],
  ['nmagisyncedmembers',['nMagiSyncedMembers',['../structkv_time_domain_data__s.html#aadd2929832bd903c78ddf59c21feea05',1,'kvTimeDomainData_s']]],
  ['nmagisyncgroups',['nMagiSyncGroups',['../structkv_time_domain_data__s.html#ab8dca255d18320cb7bd22b0448d78fb7',1,'kvTimeDomainData_s']]],
  ['nnonmagisynccards',['nNonMagiSyncCards',['../structkv_time_domain_data__s.html#af00948e6feb807b210c69fd5945e7068',1,'kvTimeDomainData_s']]],
  ['nnonmagisyncedmembers',['nNonMagiSyncedMembers',['../structkv_time_domain_data__s.html#a9cc0826be3a3477969cc862737e0f334',1,'kvTimeDomainData_s']]]
];
