var structkvm_log_msg_ex =
[
    [ "channel", "structkvm_log_msg_ex.html#aeec5b590ec61f511a514428c6cb22937", null ],
    [ "data", "structkvm_log_msg_ex.html#a62823cfc5356727ed036cea88e873777", null ],
    [ "dlc", "structkvm_log_msg_ex.html#a7d3cf80248d9011329b4b269f8b7d2c4", null ],
    [ "flags", "structkvm_log_msg_ex.html#a81a27ce50e78368b0d0de1e8767fd32d", null ],
    [ "id", "structkvm_log_msg_ex.html#a3384d9640634d49e84776a97f3e2c241", null ],
    [ "timeStamp", "structkvm_log_msg_ex.html#aa1fa735b38f32cc201831ea72527ec37", null ]
];