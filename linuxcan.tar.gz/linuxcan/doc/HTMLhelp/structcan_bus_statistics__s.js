var structcan_bus_statistics__s =
[
    [ "busLoad", "structcan_bus_statistics__s.html#a10d3e5def5be80618a372a441eaadc2f", null ],
    [ "errFrame", "structcan_bus_statistics__s.html#a54171b8fd05e42011ec548693594b4c5", null ],
    [ "extData", "structcan_bus_statistics__s.html#ad071e3666d2aedd0e3c971a3b4148385", null ],
    [ "extRemote", "structcan_bus_statistics__s.html#a14481e6fd492f4db9a7db4062d5fc199", null ],
    [ "overruns", "structcan_bus_statistics__s.html#a07399a434cb184982f6edb5976762e7f", null ],
    [ "stdData", "structcan_bus_statistics__s.html#a45656d1d249afb1ef001b9d56337b26b", null ],
    [ "stdRemote", "structcan_bus_statistics__s.html#adbc105164238a47be6d13a16cfdf07d8", null ]
];