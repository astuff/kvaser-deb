var structcan_notify_data =
[
    [ "busErr", "structcan_notify_data.html#a0f3f821312e2c5e8b29394753ef40f94", null ],
    [ "busStatus", "structcan_notify_data.html#a43a5205812ec3002d08fca45821efc3f", null ],
    [ "eventType", "structcan_notify_data.html#aa73ed1819d01004c05b8b1908ef91ef4", null ],
    [ "id", "structcan_notify_data.html#a7350fbd6ad10618f3b750b1f99ca5c3c", null ],
    [ "info", "structcan_notify_data.html#ae129dc8383274d477e1709e2df4a4d74", null ],
    [ "rx", "structcan_notify_data.html#a08ba82dcb2d1828a60a16863d4266189", null ],
    [ "rxErrorCounter", "structcan_notify_data.html#a575e147dffea7d8a2fc90141079a4fe3", null ],
    [ "status", "structcan_notify_data.html#a345c20017f48fbb3fb2b3adada292f29", null ],
    [ "tag", "structcan_notify_data.html#a3fd9a258481b2a4c0610d35a95c516f6", null ],
    [ "time", "structcan_notify_data.html#a43dc68c257e4ad93dcd26ccf96129b45", null ],
    [ "tx", "structcan_notify_data.html#a3fdd15457d2e2319e68feeb505375fe5", null ],
    [ "txErrorCounter", "structcan_notify_data.html#af474cc212c3fa114c32b574d8f9085e3", null ]
];