var struct_kva_db_protocol_properties =
[
    [ "maxMessageDlc", "struct_kva_db_protocol_properties.html#acea8c05d06bb3303dd71b41bec875533", null ],
    [ "maxSignalLength", "struct_kva_db_protocol_properties.html#a4f81fb4d85cd39f1658a64e087321245", null ]
];